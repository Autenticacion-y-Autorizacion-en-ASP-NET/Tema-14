namespace CleanArchitecture.Domain.Permissions;


public enum PermissionEnum
{
    ReadUser = 1,
    WriteUser = 2,
    UpdateUser = 3
}